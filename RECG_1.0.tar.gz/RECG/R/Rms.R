Rms <- function(array,...){
	
	return (sqrt(sum(array * array) / length(array)))
}