
int getOnset(double *signal, int signalLength, int peak, int pre, int sw, double thr);

int getEnd(double *signal, int signalLength, int peak, int post, int sw, double thr);
