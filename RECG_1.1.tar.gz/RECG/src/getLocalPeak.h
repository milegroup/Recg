

double * getLocalPeak(double *signal, int lengthSignal, int initialPos, int sw, int searchForward, int searchForMinimum);


